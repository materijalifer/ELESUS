Evo moja izvješća s labosa, nešto sam piso nešto prepiso iz raznih izvora. Manje više sve sam radio na brzinu tako da greške su moguće.
Izvještaji su ocjenjeni s : 
1. izvještaj 			[2/3]
2. izvještaj			[3/3]
3. izvještaj			[1/3]

Nemam pojma što je valjalo a što nije.
Drago mi je ako će nekom pomoć. 
